 <div class="sidebar">
        	<div class="inner">
          			<div id="sidebar-contact">
          				<h4>Contact Us Now for</h4>
          				<p class="bold-blue">$5oo.oo Towards your Deductible!</p>
          				<p>We are fully Licensed and Insured.</p>
          				<form action="#" id="quick-contact">
          					<input type="text" name="name" id="name" placeholder="Name (required)" />
          					<input type="text" name="phone" id="phone" placeholder="Phone (required)" />
          					<textarea class="text-area-full" type="text" name"description" id="description" />Case Description</textarea><br />
							<button type="submit" name="submit" class="button-blue" id="submit-quickcontact">Submit &raquo;</button>
							<span class="loading" style="display: none;">Please wait..</span> 
          				</form>
          				
          			
        			</div>
        		
        			
        			
        			<div id="sidebar-services">
        				<h2>Our Services</h2>
        				<ul>
        					<li><a href="water-remediation.php">&raquo; Water Remediation</a></li>
        					<li><a href="mold-remediation.php">&raquo; Mold Remediation</a></li>
        					<li><a href="fire-restoration.php">&raquo; Fire Restoration</a></li>
        					<li><a href="bio-hazard-remediation.php">&raquo; Bio-Hazard Remediation</a></li>
        				</ul>
        				
        				<img src="images/iirc-logo.png"  />
        			</div>
        	</div>
        </div><!-- /.col-lg-4 -->