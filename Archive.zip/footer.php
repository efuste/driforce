<!-- FOOTER -->
      <footer id="footer-container">
        <div class="container">
        	<div id="test" class="col-lg-3 mob-toggle">
        		
        			<h4>Pages</h4>
        			<span class="opener">&nbsp;</span>
        			<div class="toggle">
        				<ul>
  							<li><a href="index.php">&raquo; Home</a></li>
  							<li><a href="water-remediation.php">&raquo; Water Remediation</a></li>
  							<li><a href="mold-remediation.php">&raquo; Mold Remediation</a></li>
  							<li><a href="fire-restoration.php">&raquo; Fire Restoration</a></li>
  							<li><a href="bio-hazard-remediation.php">&raquo; Bio-Hazard Remediation</a> </li>
  							<li><a href="news.php">&raquo; News</a></li>
  							<li><a href="contact.php">&raquo; Contact Us</a></li>
  						</ul>
  					</div>
				
        	</div>
        	
        	<div class="col-lg-3 mob-toggle">
        		<h4>Services</h4>
        		<span class="opener">&nbsp;</span>

        			<div class="toggle">
        				<ul>
        					<li><a href="water-remediation.php">&raquo; Water Remediation</a></li>
  							<li><a href="mold-remediation.php">&raquo; Mold Remediation</a></li>
  							<li><a href="fire-restoration.php">&raquo; Fire Restoration</a></li>
  							<li><a href="bio-hazard-remediation.php">&raquo; Bio-Hazard Remediation</a> </li>
        				</ul>
        			</div>
        	</div>
        	
        	<div class="col-lg-3 mob-toggle">
        		<h4>Service Areas</h4>
        		<span class="opener">&nbsp;</span>

        				<div class="toggle">
        					<ul>
        						<li>&raquo; Miami-Dade</li>
        						<li>&raquo; Broward County</li>
        						<li>&raquo; Palm Beach</li>
        						<li>&raquo; Collier County</li>
        						<li>&raquo; Lee County</li>
        						<li>&raquo; Monroe County</li>
        					</ul>
        				</div>
        	</div>
        	
        	<div class="col-lg-3 mob-toggle">
        		<h4>Contact Dri-Force</h4>
        		<span class="opener">&nbsp;</span>
        		  <div class="toggle">
        				<p>24 Hours A Day</p>
        				<p>7 Days A Week</p>
        				<a href="tel:+7862802278"><p>Phone: 786-280-2278</p></a>
        				<p>Email:<a href="mailto:mcabello@driforceinc.com?subject=feedback"> mcabello@driforceinc.com</p></a>

        		</div>
        	</div>
        </div>            
        <div class="container">
        	<div class="disclaimer">       
        		<p>&copy; 2013 Dri-Force Restoration, Inc. </p>
        	</div>
		</div>
      </footer>

   
  </body>
</html>