<!-- FOOTER -->
      <footer id="footer-container">
        <div class="container">
        	<div class="col-lg-3">
        		<h4>Pages</h4>
        				<ul>
  							<li><a href="index.php">&raquo; Home</a></li>
  							<li><a href="water-remediation.php">&raquo; Water Remediation</a></li>
  							<li><a href="mold-remediation.php">&raquo; Mold Remediation</a></li>
  							<li><a href="fire-restoration.php">&raquo; Fire Restoration</a></li>
  							<li><a href="bio-hazard-remediation.php">&raquo; Bio-Hazard Remediation</a> </li>
  							<li><a href="news.php>&raquo; News</a></li>
  							<li><a href="contact.php">&raquo; Contact Us</a></li>
  						</ul>

        	</div>
        	
        	<div class="col-lg-3">
        		<h4>Service</h4>
        				<ul>
        					<li><a href="water-remediation.php">&raquo; Water Remediation</a></li>
  							<li><a href="mold-remediation.php">&raquo; Mold Remediation</a></li>
  							<li><a href="fire-restoration.php">&raquo; Fire Restoration</a></li>
  							<li><a href="bio-hazard-remediation.php">&raquo; Bio-Hazard Remediation</a> </li>
        				</ul>
        	</div>
        	
        	<div class="col-lg-3">
        		<h4>Service Areas</h4>
        				<ul>
        					<li>&raquo; Miami-Dade</li>
        					<li>&raquo; Broward County</li>
        					<li>&raquo; Palm Beach</li>
        					<li>&raquo; Collier County</li>
        					<li>&raquo; Lee County</li>
        					<li>&raquo; Monroe County</li>
        				</ul>
        	</div>
        	
        	<div class="col-lg-3">
        		<h4>Dri-Force</h4>
        				<p>Address<br />
        					Miami, Fl 33333
        				</p>
        				<p>24 Hours A Day</p>
        				<p>7 Days A Week</p>
        				<p>Phone: </p>
        				<p>Fax: </p>
        	</div>
        	<p class="pull-right"><a href="#">Back to top</a></p>
        </div>            
        <div class="container">
        	<div class="disclaimer">       
        		<p>&copy; 2013 Dri-Force Restoration, Inc. </p>
        	</div>
		</div>
      </footer>

   
  </body>
</html>