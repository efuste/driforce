 <div class="sidebar">
        	<div class="inner">
          			<div id="sidebar-contact">
          				<h4>Contact Us Now for</h4>
          				<p class="bold-blue">$5oo.oo Towards your Deductible!</p>
          				<p>We are fully Licensed and Insured.</p>
          				<form action="#" id="quick-contact">
          					<input type="text" name="name" id="name" value="Name" />
          					<input type="text" name="phone" id="phone" value="Phone" />
          					<textarea class="text-area-full" type="text" name"description" id="description" />Case Description</textarea><br />
							<button type="submit" name="submit" class="btn btn-default" id="submit-quickcontact">Submit &raquo;</button>
							<span class="loading" style="display: none;">Please wait..</span> 

          				</form>
          				
          			
        			</div>
        		
        			
        			
        			<div id="sidebar-services">
        				<h2>Our Services</h2>
        				<ul>
        					<li>&raquo; Water Remediation</li>
        					<li>&raquo; Mold Remediation</li>
        					<li>&raquo; Fire Restoration</li>
        					<li>&raquo; Bio-Hazard Remediation</li>
        				</ul>
        				
        				<img src="images/iirc-logo.png"  />
        			</div>
        	</div>
        </div><!-- /.col-lg-4 -->