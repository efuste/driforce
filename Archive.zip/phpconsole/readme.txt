Extra lightweight errors/exceptions/debugs handler for Google Chrome extension PHP Console

SVN/trunk:
http://lagger.googlecode.com/svn/trunk/PhpConsole

Project site:
http://code.google.com/p/php-console

Project updates by RSS:
http://code.google.com/feeds/p/php-console/updates/basic

Contact to developer (freelancer, looking for interesting web-projects):
http://linkedin.com/in/barbushin

PHP Console development donation:
http://web-grant.com/donation/php-console